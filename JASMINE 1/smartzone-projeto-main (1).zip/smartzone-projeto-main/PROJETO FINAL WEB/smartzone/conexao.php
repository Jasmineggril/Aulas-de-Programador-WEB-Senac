<?php
$servidor = "localhost";
$usuario = "Rafael";
$senha = "123456";
$dbname = "cadastro_loja";

//cria conexäo
$conn = mysqli_connect("$servidor","$usuario","$senha","$dbname");
