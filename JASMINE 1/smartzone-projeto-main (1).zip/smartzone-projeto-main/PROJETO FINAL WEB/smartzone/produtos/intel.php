<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>PROCESSADOR INTEL</title>
    <link rel="icon" type="image/x-icon" href="../assets/logo.ico" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="../css/global.css" rel="stylesheet" />
</head>

<body>

    <!--Menu de Navegação-->

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="../index.php">SMARTZONE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="../index.php">HOME</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="../sac.php">FALE CONOSCO</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">ACESSE SUA CONTA</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="../cadastro.php">CADASTRE-SE</a></li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li><a class="dropdown-item" href="../login.php">LOGIN</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="d-flex">
                    <button class="btn btn-outline-dark" type="submit">
                        <i class="fa-sharp fa-solid fa-cart-shopping"></i>
                        CARRINHO
                        <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <!--Card produto principal-->

    <section class="py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
                <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="../assets/processador intel.jpg"
                        alt="..." />
                </div>
                <div class="col-md-6">
                    <div class="small mb-1">BX8070110400F</div>
                    <h1 class="display-5 fw-bolder">Processador Intel Core i5-10400F, 2.9GHz (4.3GHz Max Turbo), Cache
                        12MB, 6 Núcleos, 12 Threads, LGA 1200 - BX8070110400F</h1>
                    <div class="fs-5 mb-5">

                        <div class="d-flex small text-warning mb-2">
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                            <div class="bi-star-fill"></div>
                        </div>

                        <span class="text-muted text-decoration-line-through">R$ 764,69</span><br>

                        R$ 560,99

                    </div>
                    <p class="lead">Processador Intel Core i5-10400F Os novos processadores Intel Core da 10ª Geração
                        oferecem atualizações de desempenho incríveis para melhorar a produtividade e proporcionar
                        entretenimento surpreendente, incluindo até 5,3 GHz, Intel® Wi-Fi 6 (Gig) tecnologia
                        Thunderbolt™ 3, HDR 4K, otimização de sistema inteligentes e muito mais. Produtividade acelerada
                        Recursos de desempenho inteligente integrados aprendem e se adaptam ao que você faz,
                        direcionando potência dinamicamente para onde ela é mais necessária. Os processadores Intel®
                        Core™ da 10ª Geração com memória Intel® Optane™ fornecem a responsividade para fazer mais. A
                        melhor conectividade da categoria Com Intel® Wi-Fi 6 (Gig+), conexão Ethernet Intel® I225 e
                        tecnologia Thunderbolt™ 3 integrados, os processadores Intel® Core™ da 10ª Geração oferecem
                        conectividade cabeada e sem fio rápida, garantida e versátil. Entretenimento premium Uma nova
                        arquitetura de gráficos oferece suporte a experiências visuais ultravívidas, como vídeo em HDR
                        4K e jogos a 1080p. Os processadores Intel® Core™ da 10 ª Geração com gráficos Intel® Iris® Plus
                        permitem experiências de entretenimento nunca vistas. Jogos sérios (serious gaming) Aproveite
                        jogos incríveis com alto FPS, até mesmo enquanto realiza streaming e gravação com até 5,3 GHz.
                        Turbo e aceleração da memória Intel® Optane™. Em casa ou em qualquer lugar, processadores Intel®
                        Core™ da 10ª Geração capazes de overclocking rodam as plataformas definitivas de jogos em
                        notebooks e desktops. </p>

                    <div class="d-flex">
                        <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1"
                            style="max-width: 3rem" />
                        <button class="btn btn-outline-dark flex-shrink-0" type="button">
                            <i class="bi-cart-fill me-1"></i>
                            Adicionar ao Carrinho
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Cards produtos relacionados-->

    <section class="py-5 bg-light">
        <div class="container px-4 px-lg-5 mt-5">
            <h2 class="fw-bolder mb-4">Produtos Relacionados</h2>
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <div class="col mb-5">
                    <div class="card h-100">

                        <img class="card-img-top" src="../assets/processador amd.jpg" alt="..." />

                        <div class="card-body p-4">
                            <div class="text-center">

                                <h5 class="fw-bolder">Processador AMD Ryzen 7 5700X3D, 3.6 GHz, (4.1GHz Max Turbo),
                                    Cachê 4MB, 8 Núcleos, 16 Threads, AM4 - 100-100001503WOF
                                </h5>

                                <div class="d-flex justify-content-center small text-warning mb-2">
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                </div>

                                <span class="text-muted text-decoration-line-through">R$ 2.138,37</span><br>
                                R$ 1.389,99
                            </div>
                        </div>

                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-dark mt-auto"
                                    href="./amd.php">Comprar</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Card 2-->

                <div class="col mb-5">
                    <div class="card h-100">

                        <img class="card-img-top" src="../assets/notebook vaio.jpg" alt="..." />

                        <div class="card-body p-4">
                            <div class="text-center">

                                <h5 class="fw-bolder">Notebook Vaio FH15, Intel Core I7-13700H, 32GB, SSD 1TB, Geforce
                                    RTX 3050, Tela 15.6" FULL HD, Shell Efi, Cinza Escuro </h5>

                                R$ 6.899,00

                            </div>
                        </div>

                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-dark mt-auto"
                                    href="./notevaio.php">Comprar</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Card 3-->

                <div class="col mb-5">
                    <div class="card h-100">

                        <img class="card-img-top" src="../assets/placa mae asus.jpg" alt="..." />

                        <div class="card-body p-4">
                            <div class="text-center">

                                <h5 class="fw-bolder">Placa Mãe Asus Prime H610M-A D4, LGA 1700 H610, mATX, DDR4</h5>


                                <span class="text-muted text-decoration-line-through">R$ 864,70</span><br>

                                R$ 629,99

                            </div>
                        </div>

                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-dark mt-auto"
                                    href="./placamae.php">Comprar</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Card 4-->

                <div class="col mb-5">
                    <div class="card h-100">

                        <img class="card-img-top" src="../assets/pc completo.jpg" alt="..." />

                        <div class="card-body p-4">
                            <div class="text-center">

                                <h5 class="fw-bolder">Computador Bestpc Completo, Intel Core I5, 8GB, SSD 240GB, Windows
                                    10 Trial + Monitor 19 Polegadas</h5>

                                <div class="d-flex justify-content-center small text-warning mb-2">
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                    <div class="bi-star-fill"></div>
                                </div>

                                <span class="text-muted text-decoration-line-through">R$ 997,00</span><br>
                                R$ 889,00

                            </div>
                        </div>

                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-dark mt-auto"
                                    href="./desktop.php">Comprar</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Rodape da pagina principal-->

    <footer id="rede" class="text-center text-lg-start text-white">
        <!-- Grid container -->
        <div class="container p-4 pb-0">
            <!-- Section: Links -->
            <section class="">
                <!--Grid row-->
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">
                            SMARTZONE
                        </h6>
                        <p>
                            A SmartZone é uma loja de informática que oferece uma ampla variedade de produtos
                            tecnológicos para consumidores e empresas.
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Produtos</h6>
                        <p>
                            <a class="text-white" href="../produtos/amd.php">Hardware</a>
                        </p>
                        <p>
                            <a class="text-white" href="../produtos/teclado.php">Periféricos</a>
                        </p>
                        <p>
                            <a class="text-white" href="../produtos/desktop.php">Computadores</a>
                        </p>
                        <p>
                            <a class="text-white" href="../produtos/headset.php">Games</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">
                            Acesso Rápido
                        </h6>
                        <p>
                            <a class="text-white" href="../login.php">Login</a>
                        </p>
                        <p>
                            <a class="text-white" href="../cadastro.php">Cadastre-se</a>
                        </p>
                        <p>
                            <a class="text-white" href="../seuspedidos.php">Pedidos</a>
                        </p>
                        <p>
                            <a class="text-white" href="../sac.php">Suporte</a>
                        </p>
                    </div>

                    <!-- Grid column -->
                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Contato</h6>
                        <p><i class="fas fa-home mr-3"></i> Brasil, Brasília-DF</p>
                        <p><i class="fas fa-envelope mr-3"></i> smartzone@gmail.com</p>
                        <p><i class="fas fa-phone mr-3"></i> (61) 9999-0000</p>
                        <p><i class="fas fa-print mr-3"></i> (61) 9898-0000</p>
                    </div>
                    <!-- Grid column -->
                </div>
                <!--Grid row-->
            </section>
            <!-- Section: Links -->

            <hr class="my-3">

            <!-- Section: Copyright -->
            <section class="p-3 pt-0">
                <div class="row d-flex align-items-center">
                    <!-- Grid column -->
                    <div class="col-md-7 col-lg-8 text-center text-md-start">
                        <!-- Copyright -->
                        <div class="p-3">
                            © 2024 Copyright:
                            <a class="text-white" href="#">Smartzone.com.br</a>
                        </div>
                        <!-- Copyright -->
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
                        <!-- Facebook -->
                        <a class="btn btn-outline-light btn-floating m-1" class="text-white" role="button"><i
                                class="fab fa-facebook-f"></i></a>

                        <!-- Twitter -->
                        <a class="btn btn-outline-light btn-floating m-1" class="text-white" role="button"><i
                                class="fab fa-twitter"></i></a>

                        <!-- Google -->
                        <a class="btn btn-outline-light btn-floating m-1" class="text-white" role="button"><i
                                class="fab fa-google"></i></a>

                        <!-- Instagram -->
                        <a class="btn btn-outline-light btn-floating m-1" class="text-white" role="button"><i
                                class="fab fa-instagram"></i></a>
                    </div>
                    <!-- Grid column -->
                </div>
            </section>
            <!-- Section: Copyright -->
        </div>
        <!-- Grid container -->
    </footer>

    <!--script-->

    <script src="https://kit.fontawesome.com/2efb6f99a5.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/scripts.js"></script>
</body>

</html>